export const C = {carbon: '#171917', graphite: '#333832', lime: '#C8F36B', porcelain: '#F5F5F0', white: '#FFFFFF'};
export const FPS = 30;
export const DURATION = 38 * FPS;
export const sec = (s: number) => Math.round(s * FPS);
