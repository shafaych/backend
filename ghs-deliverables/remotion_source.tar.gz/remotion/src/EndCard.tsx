import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import {C} from './theme';

const rise = (f: number, start: number) => interpolate(f, [start, start + 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});

export const EndCard: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const m = spring({frame: f - 14, fps, config: {damping: 200}, durationInFrames: 22});
  const line = interpolate(f, [26, 50], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const sans = "'Inter','Helvetica Neue',Arial,sans-serif";
  const ctaP = rise(f, 118);
  const glow = interpolate(f, [128, 150, 172], [0, 1, 0.55], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{background: C.carbon}}>
      <AbsoluteFill style={{background: `radial-gradient(circle at 50% 38%, ${C.graphite} 0%, ${C.carbon} 62%)`, opacity: 0.9}} />
      {/* Typographic wordmark (set in type, not an official logo) */}
      <div style={{position: 'absolute', top: 520, left: 0, width: 1080, textAlign: 'center', overflow: 'hidden', height: 190}}>
        <div style={{transform: `translateY(${(1 - m) * 110}%)`, fontFamily: "'Anton',Impact,sans-serif", fontSize: 168, color: C.white, letterSpacing: 6, lineHeight: 1.1}}>GHS</div>
      </div>
      <div style={{position: 'absolute', top: 716, left: 0, width: 1080, textAlign: 'center', overflow: 'hidden', height: 110}}>
        <div style={{transform: `translateY(${(1 - m) * 110}%)`, fontFamily: "'Anton',Impact,sans-serif", fontSize: 78, color: C.lime, letterSpacing: 18, lineHeight: 1.2}}>CUSTOM GEAR</div>
      </div>
      <div style={{position: 'absolute', top: 850, left: 540 - 260 * line, width: 520 * line, height: 6, background: C.lime}} />
      <div style={{position: 'absolute', top: 900, width: 1080, textAlign: 'center', fontFamily: "'Anton',Impact,sans-serif", fontSize: 54, color: C.porcelain, letterSpacing: 3, opacity: rise(f, 48), transform: `translateY(${(1 - rise(f, 48)) * 20}px)`}}>YOUR VISION. OUR PRODUCTION.</div>
      <div style={{position: 'absolute', top: 1000, width: 1080, textAlign: 'center', fontFamily: sans, fontWeight: 700, fontSize: 31, color: C.porcelain, letterSpacing: 4, opacity: rise(f, 70) * 0.9}}>IN-HOUSE SPORTSWEAR MANUFACTURING</div>
      <div style={{position: 'absolute', top: 1058, width: 1080, textAlign: 'center', fontFamily: sans, fontWeight: 700, fontSize: 31, color: C.lime, letterSpacing: 4, opacity: rise(f, 86)}}>MOQ STARTING AT 10 PIECES</div>
      <div style={{position: 'absolute', top: 1190, left: 140, width: 800, height: 118, borderRadius: 60, background: C.lime, opacity: ctaP, transform: `scale(${0.92 + 0.08 * ctaP})`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 ${60 * glow}px rgba(200,243,107,${0.45 * glow})`}}>
        <span style={{fontFamily: sans, fontWeight: 700, fontSize: 36, color: C.carbon, letterSpacing: 2.5}}>REQUEST YOUR CUSTOM QUOTE</span>
      </div>
      <div style={{position: 'absolute', top: 1346, width: 1080, textAlign: 'center', fontFamily: sans, fontWeight: 500, fontSize: 38, color: C.white, letterSpacing: 1.5, opacity: rise(f, 134)}}>ghscustomgear.com</div>
    </AbsoluteFill>
  );
};
