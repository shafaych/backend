import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import {C} from './theme';

// Masked line reveal: text slides up from behind a clipping mask, exits by sliding up.
export const MaskLine: React.FC<{text: string; start: number; end: number; size?: number; color?: string; top: number; left?: number; letter?: number; font?: 'anton' | 'inter'}> =
({text, start, end, size = 112, color = C.white, top, left = 72, letter = 1, font = 'anton'}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const inP = spring({frame: f - start, fps, config: {damping: 200, mass: 0.7}, durationInFrames: 16});
  const outP = interpolate(f, [end - 8, end], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.cubic)});
  const y = (1 - inP) * 115 - outP * 115;
  const fam = font === 'anton' ? "'Anton', 'Impact', sans-serif" : "'Inter', 'Helvetica Neue', Arial, sans-serif";
  return (
    <div style={{position: 'absolute', left, top, width: 1080 - left * 2, overflow: 'hidden', lineHeight: 1.08, paddingTop: 6, paddingBottom: 6}}>
      <div style={{transform: `translateY(${y}%)`, fontFamily: fam, fontSize: size, color, letterSpacing: letter, textTransform: 'uppercase', fontWeight: font === 'inter' ? 700 : 400, textShadow: '0 4px 24px rgba(0,0,0,.45)'}}>{text}</div>
    </div>
  );
};

export const Bar: React.FC<{start: number; end: number; top: number; left?: number; w?: number}> = ({start, end, top, left = 72, w = 140}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [start, start + 12, end - 8, end], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  return <div style={{position: 'absolute', left, top, width: w * p, height: 8, background: C.lime}} />;
};
