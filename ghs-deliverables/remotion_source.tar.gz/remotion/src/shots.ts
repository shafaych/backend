// Edit decision list. `at`/`dur` = output timeline (s); `src`/`in` = source file + in-point (s).
// mode: full = 9:16 cover; window = horizontal editorial window over blurred background.
export type Shot = {
  id: string; src: string; in: number; at: number; dur: number;
  mode: 'full' | 'window'; zoom?: [number, number]; focus?: [number, number];
  winH?: number; winTop?: number; label: string;
};
export const SHOTS: Shot[] = [
  // SCENE 01 - hook (sewing close-up, blue fabric, needle + presser foot)
  {id: '01a', src: 'sewing.mp4', in: 1.0, at: 0, dur: 2.0, mode: 'full', zoom: [1.0, 1.08], focus: [0.4, 0.3], label: 'Needle/presser foot on blue fabric'},
  {id: '01b', src: 'sewing.mp4', in: 15.0, at: 2.0, dur: 2.0, mode: 'full', zoom: [1.0, 1.1], focus: [0.5, 0.45], label: 'Hands guiding striped jersey under needle'},
  // SCENE 02 - craftsmanship alternation
  {id: '02a', src: 'purple.mp4', in: 1.8, at: 4.0, dur: 1.5, mode: 'full', zoom: [1.0, 1.07], focus: [0.5, 0.5], label: 'Hands folding purple shorts'},
  {id: '02b', src: 'sewing.mp4', in: 19.0, at: 5.5, dur: 1.5, mode: 'full', zoom: [1.04, 1.0], focus: [0.5, 0.5], label: 'Needle detail, striped panel'},
  {id: '02c', src: 'purple.mp4', in: 3.0, at: 7.0, dur: 1.5, mode: 'full', zoom: [1.0, 1.06], focus: [0.6, 0.4], label: 'Steam press on numbered garment'},
  {id: '02d', src: 'sewing.mp4', in: 22.5, at: 8.5, dur: 1.5, mode: 'full', zoom: [1.0, 1.06], focus: [0.5, 0.5], label: 'Hands feeding fabric, needle down'},
  // SCENE 03 - factory floor (red garments)
  {id: '03a', src: 'factory.mp4', in: 0.4, at: 10.0, dur: 3.5, mode: 'window', winH: 720, zoom: [1.0, 1.06], focus: [0.5, 0.4], label: 'Three workers folding red garments, wide'},
  {id: '03b', src: 'factory.mp4', in: 7.4, at: 13.5, dur: 1.5, mode: 'window', winH: 720, zoom: [1.0, 1.1], focus: [0.5, 0.5], label: 'Red garment stacks, close'},
  {id: '03c', src: 'factory.mp4', in: 12.0, at: 15.0, dur: 2.0, mode: 'window', winH: 720, zoom: [1.45, 1.55], focus: [0.18, 0.45], label: 'Packing table, worker close crop'},
  // SCENE 04 - order preparation
  {id: '04a', src: 'counting.mp4', in: 0.2, at: 17.0, dur: 3.0, mode: 'window', winH: 720, zoom: [1.0, 1.06], focus: [0.5, 0.5], label: 'Yellow garment stacks, cartons behind'},
  {id: '04b', src: 'kings.mp4', in: 0.4, at: 20.0, dur: 2.5, mode: 'window', winH: 720, zoom: [1.0, 1.08], focus: [0.7, 0.5], label: 'Yellow stack, worker labelling (match on yellow)'},
  {id: '04c', src: 'counting.mp4', in: 6.2, at: 22.5, dur: 2.5, mode: 'window', winH: 720, zoom: [1.0, 1.06], focus: [0.4, 0.5], label: 'Workers at production table with stacks'},
  // SCENE 05 - finished products
  {id: '05a', src: 'kings.mp4', in: 8.0, at: 25.0, dur: 2.5, mode: 'window', winH: 900, zoom: [1.0, 1.1], focus: [0.5, 0.55], label: 'Orange / red / tan stacks'},
  {id: '05b', src: 'kings.mp4', in: 10.6, at: 27.5, dur: 2.5, mode: 'window', winH: 900, zoom: [1.0, 1.1], focus: [0.6, 0.5], label: 'Red-orange-blue transition pan'},
  {id: '05c', src: 'kings.mp4', in: 13.2, at: 30.0, dur: 2.0, mode: 'window', winH: 900, zoom: [1.0, 1.08], focus: [0.5, 0.5], label: 'Blue and yellow stacks'},
];
