import React from 'react';
import {AbsoluteFill, interpolate, OffthreadVideo, staticFile, useCurrentFrame, Easing} from 'remotion';
import {Shot} from './shots';
import {FPS} from './theme';

// Consistent natural grade: gentle contrast, slight saturation, no sharpening.
const GRADE = 'contrast(1.07) saturate(1.04) brightness(1.0)';

export const Footage: React.FC<{shot: Shot}> = ({shot}) => {
  const f = useCurrentFrame();
  const n = Math.round(shot.dur * FPS);
  const [z0, z1] = shot.zoom ?? [1, 1];
  const z = interpolate(f, [0, n], [z0, z1], {easing: Easing.inOut(Easing.quad), extrapolateRight: 'clamp'});
  const [fx, fy] = shot.focus ?? [0.5, 0.5];
  const startFrom = Math.round(shot.in * FPS);
  const src = staticFile(shot.src);
  const vid = (style: React.CSSProperties) => (
    <OffthreadVideo src={src} startFrom={startFrom} muted style={style} />
  );
  if (shot.mode === 'full') {
    return (
      <AbsoluteFill style={{overflow: 'hidden', background: '#000'}}>
        {vid({width: 1080, height: 1920, objectFit: 'cover', transform: `scale(${z})`, transformOrigin: `${fx * 100}% ${fy * 100}%`, filter: GRADE})}
      </AbsoluteFill>
    );
  }
  const H = shot.winH ?? 720;
  const top = shot.winTop ?? Math.round((1920 - H) / 2) - 90;
  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      {vid({width: 1080, height: 1920, objectFit: 'cover', filter: `blur(46px) brightness(0.42) saturate(1.1)`, transform: 'scale(1.25)'})}
      <div style={{position: 'absolute', left: 0, top, width: 1080, height: H, overflow: 'hidden', boxShadow: '0 30px 80px rgba(0,0,0,.55)'}}>
        {vid({width: 1080, height: H, objectFit: 'cover', transform: `scale(${z})`, transformOrigin: `${fx * 100}% ${fy * 100}%`, filter: GRADE})}
      </div>
      <div style={{position: 'absolute', left: 0, top: top - 6, width: 120, height: 6, background: '#C8F36B'}} />
    </AbsoluteFill>
  );
};
