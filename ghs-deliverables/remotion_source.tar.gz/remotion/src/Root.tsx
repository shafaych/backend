import React from 'react';
import {AbsoluteFill, Composition, Sequence, interpolate, useCurrentFrame, Easing} from 'remotion';
import '@fontsource/anton/400.css';
import '@fontsource/inter/700.css';
import '@fontsource/inter/500.css';
import {C, DURATION, FPS, sec} from './theme';
import {SHOTS} from './shots';
import {Footage} from './Footage';
import {Bar, MaskLine} from './Type';
import {EndCard} from './EndCard';

const Vignette: React.FC = () => (
  <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,.38) 100%)', pointerEvents: 'none'}} />
);
const Scrim: React.FC<{top?: boolean}> = ({top}) => (
  <AbsoluteFill style={{background: top ? 'linear-gradient(to bottom, rgba(23,25,23,.55), rgba(23,25,23,0) 30%)' : 'linear-gradient(to top, rgba(23,25,23,.82), rgba(23,25,23,0) 42%)'}} />
);
const T = (s: number) => sec(s);

const Main: React.FC = () => {
  const f = useCurrentFrame();
  // soften the cut into the end card: footage fades to carbon over 32.0-32.7s
  const fade = interpolate(f, [T(31.7), T(32.5)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
  return (
    <AbsoluteFill style={{background: C.carbon}}>
      {SHOTS.map((s) => (
        <Sequence key={s.id} from={T(s.at)} durationInFrames={T(s.dur) + 2}>
          <Footage shot={s} />
        </Sequence>
      ))}
      <Vignette />
      <Sequence from={0} durationInFrames={T(32.5)}><Scrim /></Sequence>
      <AbsoluteFill style={{background: C.carbon, opacity: fade}} />

      {/* SCENE 01 */}
      <Sequence from={0} durationInFrames={T(4.0)}>
        <Bar start={4} end={T(4)} top={1190} />
        <MaskLine text="Not just a manufacturer." start={5} end={T(2.0)} top={1230} size={118} />
        <MaskLine text="The people behind" start={T(2.1)} end={T(3.9)} top={1230} size={104} />
        <MaskLine text="your brand." start={T(2.3)} end={T(3.9)} top={1340} size={104} color={C.lime} />
      </Sequence>
      {/* SCENE 02 */}
      <Sequence from={T(4.0)} durationInFrames={T(6.0)}>
        <Bar start={4} end={T(3.0)} top={1190} />
        <MaskLine text="Real hands." start={5} end={T(3.0)} top={1230} size={150} />
        <Bar start={T(3.2)} end={T(5.8)} top={1190} />
        <MaskLine text="Real craftsmanship." start={T(3.2)} end={T(5.8)} top={1230} size={124} color={C.lime} />
      </Sequence>
      {/* SCENE 03 */}
      <Sequence from={T(10.0)} durationInFrames={T(7.0)}>
        <MaskLine text="Inside GHS" start={6} end={T(6.8)} top={1215} size={140} />
        <MaskLine text="Custom Gear." start={12} end={T(6.8)} top={1345} size={140} color={C.lime} />
        <MaskLine text="In-house sportswear manufacturing" start={22} end={T(6.8)} top={1500} size={34} font="inter" letter={3} color={C.porcelain} />
      </Sequence>
      {/* SCENE 04 */}
      <Sequence from={T(17.0)} durationInFrames={T(8.0)}>
        <MaskLine text="From production..." start={4} end={T(3.4)} top={1215} size={118} />
        <MaskLine text="...to order preparation." start={T(3.7)} end={T(7.7)} top={1215} size={96} color={C.lime} />
      </Sequence>
      {/* SCENE 05 */}
      <Sequence from={T(25.0)} durationInFrames={T(7.3)}>
        <Bar start={4} end={T(3.4)} top={1295} />
        <MaskLine text="Built for teams." start={5} end={T(3.4)} top={1330} size={128} />
        <MaskLine text="Made for brands." start={T(3.6)} end={T(7.2)} top={1330} size={128} color={C.lime} />
      </Sequence>
      {/* SCENE 06 */}
      <Sequence from={T(32.0)} durationInFrames={DURATION - T(32.0)}><EndCard /></Sequence>
    </AbsoluteFill>
  );
};

export const Root: React.FC = () => (
  <Composition id="GHS" component={Main} durationInFrames={DURATION} fps={FPS} width={1080} height={1920} />
);
